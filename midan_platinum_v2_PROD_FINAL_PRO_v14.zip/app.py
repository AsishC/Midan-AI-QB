from dotenv import load_dotenv
from pathlib import Path
load_dotenv(dotenv_path=Path(__file__).resolve().parent / ".env", override=False)
import os
import json
import hashlib
import datetime
from typing import List, Optional, Dict

from fastapi import FastAPI, Request, Form, Depends, HTTPException, File, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from starlette.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy.orm import Session
from openai import OpenAI

from database import (
    SessionLocal,
    init_db,
    Category,
    Question,
    MediaCandidate,
    AuditLog,
)

from agents.media_agent import run_media_agent_for_question_ids, build_media_hint
from agents.factcheck_agent import run_factcheck_agent_for_question_ids
from agents.validate_agent import run_validate_agent_for_question_ids

# -------------------------------------------------------------------
# Basic config
# -------------------------------------------------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")
STATIC_DIR = os.path.join(BASE_DIR, "static")
MEDIA_DIR = os.path.join(STATIC_DIR, "media")
ORIGINAL_MEDIA_DIR = os.path.join(MEDIA_DIR, "original")

os.makedirs(ORIGINAL_MEDIA_DIR, exist_ok=True)

app = FastAPI()

app.add_middleware(
    SessionMiddleware,
    secret_key=os.environ.get("SESSION_SECRET_KEY", "change-me-please"),
)

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
templates = Jinja2Templates(directory=TEMPLATES_DIR)

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
if not OPENAI_API_KEY:
    print("[WARN] OPENAI_API_KEY not set – AI features will fail.")
client = OpenAI(api_key=OPENAI_API_KEY)


# -------------------------------------------------------------------
# DB session dependency
# -------------------------------------------------------------------

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# -------------------------------------------------------------------
# Simple helpers
# -------------------------------------------------------------------

def _sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _normalize_question_text(stem_en: str, stem_ar: str, answer_en: str, answer_ar: str) -> str:
    parts = [
        (stem_en or "").strip().lower(),
        (stem_ar or "").strip().lower(),
        (answer_en or "").strip().lower(),
        (answer_ar or "").strip().lower(),
    ]
    return " | ".join(p for p in parts if p)


def _current_user(request: Request) -> Optional[str]:
    return request.session.get("user")


def _require_login(request: Request) -> None:
    if not _current_user(request):
        raise HTTPException(status_code=401, detail="Not authenticated")


def _log_audit(
    db: Session,
    user: Optional[str],
    action: str,
    entity: str,
    entity_id: Optional[int],
    details: Dict,
):
    entry = AuditLog(
        actor=user or "system",
        message=action,
        entity=entity,
        entity_id=entity_id,
        before_json=None,
        after_json=json.dumps(details, ensure_ascii=False),
        created_at=datetime.datetime.utcnow(),
    )
    db.add(entry)
    db.commit()


# -------------------------------------------------------------------
# Startup
# -------------------------------------------------------------------

@app.on_event("startup")
def on_startup():
    init_db()
    print("[INIT] Database initialized.")


# -------------------------------------------------------------------
# Authentication (very simple)
# -------------------------------------------------------------------

# ----------------------------
# LOGIN (Arabic-first UI)
# ----------------------------

from fastapi import Form, Request
from fastapi.responses import RedirectResponse
from starlette.status import HTTP_302_FOUND
import os

ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASS = os.getenv("ADMIN_PASS") or os.getenv("QB_ADMIN_PASSWORD") or "admin"  # default for local/demo


@app.get("/login")
def login_page(request: Request):
    return templates.TemplateResponse(
        "login.html",
        {"request": request}
    )


@app.post("/login")
async def login(
    request: Request,
    username: Optional[str] = Form(None),
    password: Optional[str] = Form(None)
):
    """
    Accepts credentials from either:
      1) HTML form POST (application/x-www-form-urlencoded or multipart/form-data), or
      2) JSON body (application/json) for API/JS clients.
    """

    # If the request is JSON (or the form fields were not provided), try JSON parsing.
    if username is None or password is None:
        try:
            data = await request.json()
            if isinstance(data, dict):
                username = data.get("username")
                password = data.get("password")
        except Exception:
            pass

    # Basic validation (avoid FastAPI "Field required" errors for empty bodies)

    # If the UI only posts a password (common in simple admin panels),
    # treat the username as "admin" by default.
    if (not username) and password:
        username = "admin"

    if not username or not password:
        return templates.TemplateResponse(
            "login.html",
            {"request": request, "error": "Username and password are required."},
        )

    if username == ADMIN_USER and password == ADMIN_PASS:
        request.session["user"] = username
        return RedirectResponse("/", status_code=HTTP_302_FOUND)

    return templates.TemplateResponse(
        "login.html",
        {"request": request, "error": "Invalid username or password"},
    )





@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


# -------------------------------------------------------------------
# Dashboard with Audit
# -------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db)):
    if not _current_user(request):
        return RedirectResponse("/login", status_code=303)

    total_categories = db.query(Category).count()
    total_questions = db.query(Question).count()

    # Media statuses are standardized as: PENDING / REVIEW_REQUIRED / APPROVED
    pending_media = db.query(Question).filter(Question.media_status == "PENDING").count()
    media_review = db.query(Question).filter(Question.media_status == "REVIEW_REQUIRED").count()
    media_approved = db.query(Question).filter(Question.media_status == "APPROVED").count()

    active_questions = db.query(Question).filter(Question.status == "active").count()

    pending_factcheck = db.query(Question).filter(Question.status == "needs_factcheck").count()
    pending_validation = db.query(Question).filter(Question.status == "needs_validation").count()

    # Build per-category stats for dashboard table
    categories = db.query(Category).order_by(Category.id.asc()).all()
    cat_stats = []
    for c in categories:
        total = db.query(Question).filter(Question.category_id == c.id).count()
        active = db.query(Question).filter(Question.category_id == c.id, Question.status == "active").count()
        draft = db.query(Question).filter(Question.category_id == c.id, Question.status != "active").count()

        c_media_approved = db.query(Question).filter(Question.category_id == c.id, Question.media_status == "APPROVED").count()
        c_media_pending = db.query(Question).filter(Question.category_id == c.id, Question.media_status == "PENDING").count()
        c_media_review = db.query(Question).filter(Question.category_id == c.id, Question.media_status == "REVIEW_REQUIRED").count()

        cat_stats.append(
            {
                "id": c.id,
                "name_en": c.name_en,
                "name_ar": c.name_ar,
                "scope": c.scope,
                "saudi_ratio": c.saudi_ratio,
                "total": total,
                "active": active,
                "draft": draft,
                "media_approved": c_media_approved,
                "media_pending": c_media_pending,
                "media_review": c_media_review,
            }
        )

    # Recent audit
    recent_audit = (
        db.query(AuditLog)
        .order_by(AuditLog.created_at.desc())
        .limit(10)
        .all()
    )

    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "user": _current_user(request),
            "total_categories": total_categories,
            "total_questions": total_questions,
            "active_questions": active_questions,
            "pending_media": pending_media,
            "media_review": media_review,
            "media_approved": media_approved,
            "pending_factcheck": pending_factcheck,
            "pending_validation": pending_validation,
            "cat_stats": cat_stats,
            "recent_audit": recent_audit,
            "logs": recent_audit,
        },
    )
@app.get("/categories", response_class=HTMLResponse)
def categories_list(request: Request, db: Session = Depends(get_db)):
    _require_login(request)
    cats = db.query(Category).order_by(Category.id.desc()).all()
    return templates.TemplateResponse(
        "categories.html",
        {"request": request, "categories": cats, "user": _current_user(request)},
    )


@app.get("/categories/new", response_class=HTMLResponse)
def categories_new_form(request: Request):
    _require_login(request)
    return templates.TemplateResponse(
        "category_form.html",
        {"request": request, "category": None, "user": _current_user(request)},
    )


@app.post("/categories/new")
def categories_new_post(
    request: Request,
    name_en: str = Form(...),
    name_ar: str = Form(""),
    scope: str = Form("global"),
    subtopic: str = Form(""),
    description_en: str = Form(""),
    description_ar: str = Form(""),
    saudi_safe_notes: str = Form(""),
    is_current_affairs: bool = Form(False),
    db: Session = Depends(get_db),
):
    _require_login(request)
    name_en = (name_en or "").strip()
    if not name_en:
        raise HTTPException(status_code=400, detail="Category name (EN) is required")

    existing = (
        db.query(Category)
        .filter(Category.name_en.ilike(name_en))
        .first()
    )
    if existing:
        return RedirectResponse("/categories", status_code=303)

    cat = Category(
        name_en=name_en,
        name_ar=(name_ar or "").strip(),
        scope=(scope or "global").strip(),
        subtopic=(subtopic or "").strip(),
        description_en=(description_en or "").strip(),
        description_ar=(description_ar or "").strip(),
        saudi_safe_notes=(saudi_safe_notes or "").strip(),
        is_current_affairs=bool(is_current_affairs),
        created_at=datetime.datetime.utcnow(),
    )
    db.add(cat)
    db.commit()

    _log_audit(
        db,
        _current_user(request),
        "create",
        "Category",
        cat.id,
        {
            "name_en": cat.name_en,
            "scope": cat.scope,
            "is_current_affairs": cat.is_current_affairs,
        },
    )

    return RedirectResponse("/categories", status_code=303)


@app.get("/categories/{category_id}/edit", response_class=HTMLResponse)
def categories_edit_form(
    request: Request,
    category_id: int,
    db: Session = Depends(get_db),
):
    _require_login(request)
    cat = db.query(Category).get(category_id)
    if not cat:
        raise HTTPException(status_code=404, detail="Category not found")

    return templates.TemplateResponse(
        "category_form.html",
        {"request": request, "category": cat, "user": _current_user(request)},
    )


@app.post("/categories/{category_id}/edit")
def categories_edit_post(
    request: Request,
    category_id: int,
    name_en: str = Form(...),
    name_ar: str = Form(""),
    scope: str = Form("global"),
    subtopic: str = Form(""),
    description_en: str = Form(""),
    description_ar: str = Form(""),
    saudi_safe_notes: str = Form(""),
    is_current_affairs: bool = Form(False),
    db: Session = Depends(get_db),
):
    _require_login(request)

    cat = db.query(Category).get(category_id)
    if not cat:
        raise HTTPException(status_code=404, detail="Category not found")

    old = {
        "name_en": cat.name_en,
        "scope": cat.scope,
        "subtopic": cat.subtopic,
        "description_en": cat.description_en,
        "is_current_affairs": cat.is_current_affairs,
    }

    cat.name_en = (name_en or "").strip()
    cat.name_ar = (name_ar or "").strip()
    cat.scope = (scope or "global").strip()
    cat.subtopic = (subtopic or "").strip()
    cat.description_en = (description_en or "").strip()
    cat.description_ar = (description_ar or "").strip()
    cat.saudi_safe_notes = (saudi_safe_notes or "").strip()
    cat.is_current_affairs = bool(is_current_affairs)
    db.commit()

    _log_audit(
        db,
        _current_user(request),
        "update",
        "Category",
        cat.id,
        {"old": old, "new": {
            "name_en": cat.name_en,
            "scope": cat.scope,
            "subtopic": cat.subtopic,
            "description_en": cat.description_en,
            "is_current_affairs": cat.is_current_affairs,
        }},
    )

    return RedirectResponse("/categories", status_code=303)


# -------------------------------------------------------------------
# Questions list & detail
# -------------------------------------------------------------------


@app.get("/categories/{category_id}/questions", response_class=HTMLResponse)
def category_questions(
    request: Request,
    category_id: int,
    status: Optional[str] = None,
    q: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """Alias route used by some templates/links."""
    _require_login(request)
    return questions_list(request=request, category_id=category_id, status=status, q=q, db=db)


@app.get("/questions", response_class=HTMLResponse)
def questions_list(
    request: Request,
    category_id: Optional[int] = None,
    status: Optional[str] = None,
    q: Optional[str] = None,
    db: Session = Depends(get_db),
):
    _require_login(request)

    query = db.query(Question).order_by(Question.id.desc())

    if category_id:
        query = query.filter(Question.category_id == category_id)
    if status:
        query = query.filter(Question.status == status)
    if q:
        like = f"%{q}%"
        query = query.filter(
            (Question.stem_en.ilike(like))
            | (Question.stem_ar.ilike(like))
            | (Question.answer_en.ilike(like))
            | (Question.answer_ar.ilike(like))
        )

    questions = query.limit(500).all()
    cats = db.query(Category).all()
    cats_map = {c.id: c for c in cats}

    return templates.TemplateResponse(
        "questions.html",
        {
            "request": request,
            "questions": questions,
            "categories": cats,
            "cats_map": cats_map,
            "filter_category_id": category_id,
            "filter_status": status,
            "filter_q": q,
            "user": _current_user(request),
        },
    )


@app.get("/questions/all", response_class=HTMLResponse)
def questions_all(
    request: Request,
    db: Session = Depends(get_db),
):
    _require_login(request)
    questions = db.query(Question).order_by(Question.id.desc()).limit(2000).all()
    cats = db.query(Category).all()
    cats_map = {c.id: c for c in cats}
    return templates.TemplateResponse(
        "questions_all.html",
        {
            "request": request,
            "questions": questions,
            "categories": cats,
            "cats_map": cats_map,
            "user": _current_user(request),
        },
    )


@app.get("/questions/{question_id}/edit", response_class=HTMLResponse)
def question_edit_form(
    request: Request,
    question_id: int,
    db: Session = Depends(get_db),
):
    _require_login(request)

    q = db.query(Question).get(question_id)
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")

    cats = db.query(Category).all()
    cat = next((c for c in cats if c.id == q.category_id), None)

    hint_text = build_media_hint(
        cat.name_en if cat else "",
        q.subtopic or (cat.subtopic if cat else "") or "",
        q.hint or "",
        q.stem_en or "",
        q.answer_en or "",
        q.question_type or "",
        q.region or "saudi",
    )

    media_candidates = (
        db.query(MediaCandidate)
        .filter(MediaCandidate.question_id == q.id)
        .order_by(MediaCandidate.score.desc())
        .all()
    )

    return templates.TemplateResponse(
        "question_edit.html",
        {
            "request": request,
            "question": q,
            "categories": cats,
            "hint_text": hint_text,
            "media_candidates": media_candidates,
            "candidates": media_candidates,
            "user": _current_user(request),
        },
    )


@app.post("/questions/{question_id}/edit")
def question_edit_post(
    request: Request,
    question_id: int,
    category_id: int = Form(...),
    stem_en: str = Form(""),
    stem_ar: str = Form(""),
    answer_en: str = Form(""),
    answer_ar: str = Form(""),
    option1_en: str = Form(""),
    option2_en: str = Form(""),
    option3_en: str = Form(""),
    option4_en: str = Form(""),
    option1_ar: str = Form(""),
    option2_ar: str = Form(""),
    option3_ar: str = Form(""),
    option4_ar: str = Form(""),
    correct_option_index: Optional[int] = Form(None),
    difficulty: str = Form("medium"),
    q_type: str = Form("text"),
    answer_type: str = Form("text"),
    region: str = Form("saudi"),
    subtopic: str = Form(""),
    hint: str = Form(""),
    status: str = Form("draft"),
    media_query: str = Form(""),
    media_url: str = Form(""),
    media_type: str = Form(""),
    media_status: str = Form("none"),
    media_selected_source: str = Form(""),
    media_selected_score: str = Form(""),
    db: Session = Depends(get_db),
):
    _require_login(request)

    q = db.query(Question).get(question_id)
    if not q:
        raise HTTPException(status_code=404, detail="Question not found")

    old = {
        "stem_en": q.stem_en,
        "stem_ar": q.stem_ar,
        "answer_en": q.answer_en,
        "answer_ar": q.answer_ar,
        "status": q.status,
        "media_url": q.media_url,
    }

    q.category_id = category_id
    q.stem_en = (stem_en or "").strip()
    q.stem_ar = (stem_ar or "").strip()
    q.answer_en = (answer_en or "").strip()
    q.answer_ar = (answer_ar or "").strip()

    q.option1_en = (option1_en or "").strip()
    q.option2_en = (option2_en or "").strip()
    q.option3_en = (option3_en or "").strip()
    q.option4_en = (option4_en or "").strip()

    q.option1_ar = (option1_ar or "").strip()
    q.option2_ar = (option2_ar or "").strip()
    q.option3_ar = (option3_ar or "").strip()
    q.option4_ar = (option4_ar or "").strip()

    q.correct_option_index = correct_option_index
    q.difficulty = (difficulty or "medium").strip()
    q.question_type = (q_type or "text").strip()
    q.answer_type = (answer_type or "text").strip()
    q.region = (region or "saudi").strip()
    q.subtopic = (subtopic or "").strip()
    q.hint = (hint or "").strip()
    q.status = (status or "draft").strip()
    q.media_query = (media_query or "").strip()
    q.media_url = (media_url or "").strip()
    q.media_type = (media_type or "").strip()
    q.media_status = (media_status or "").strip()
    q.media_selected_source = (media_selected_source or "").strip()
    q.media_selected_score = (media_selected_score or "").strip()

    norm = _normalize_question_text(q.stem_en, q.stem_ar, q.answer_en, q.answer_ar)
    q.dedup_key = _sha(norm) if norm else None

    db.commit()

    _log_audit(
        db,
        _current_user(request),
        "update",
        "Question",
        q.id,
        {"old": old, "new": {
            "stem_en": q.stem_en,
            "stem_ar": q.stem_ar,
            "answer_en": q.answer_en,
            "answer_ar": q.answer_ar,
            "status": q.status,
            "media_url": q.media_url,
        }},
    )

    return RedirectResponse(f"/questions/{q.id}/edit", status_code=303)


# -------------------------------------------------------------------
# AI question generation
# -------------------------------------------------------------------

@app.get("/ai/generate", response_class=HTMLResponse)
def ai_generate_form(request: Request, db: Session = Depends(get_db)):
    _require_login(request)
    cats = db.query(Category).order_by(Category.name_en.asc()).all()
    return templates.TemplateResponse(
        "ai_generate.html",
        {"request": request, "categories": cats, "user": _current_user(request)},
    )


@app.post("/ai/generate", response_class=HTMLResponse)
def ai_generate_post(
    request: Request,
    db: Session = Depends(get_db),
    category_id: int = Form(...),
    difficulty: str = Form("medium"),
    question_mode: str = Form("TEXT"),  # TEXT or MEDIA
    media_type: str = Form("picture"),  # used only when MEDIA
    answer_type: str = Form("mcq_selection"),  # mcq_selection or text_input
    count: int = Form(5),
    subtopic: str = Form(""),
    hint: str = Form(""),
):
    """Production AI generation.

    Rules enforced:
    - No interpretive/philosophical questions.
    - Two modes: TEXT vs MEDIA.
    - Two answer formats: MCQ (1 correct + 3 close distractors) or TEXT (single exact answer).
    - Difficulty must be adhered to by explicit constraints.
    """
    _require_login(request)

    cat = db.query(Category).get(category_id)
    if not cat:
        raise HTTPException(status_code=404, detail="Category not found")

    question_mode = (question_mode or "TEXT").upper().strip()
    if question_mode not in ("TEXT", "MEDIA"):
        question_mode = "TEXT"

    media_type = (media_type or "picture").lower().strip()
    if media_type not in ("logo", "picture", "audio", "video", "youtube"):
        media_type = "picture"

    # Backward compatibility: if older UI sends question_type
    form = request._form if hasattr(request, "_form") else None

    difficulty = (difficulty or "medium").lower().strip()
    if difficulty not in ("easy", "medium", "hard", "expert"):
        difficulty = "medium"

    answer_type = (answer_type or "mcq_selection").lower().strip()
    is_mcq = answer_type.startswith("mcq")

    # --- prompts ---
    common_rules = (
        "STRICT RULES (must comply):\n"
        "1) Questions must be factual and have a single clear correct answer.\n"
        "2) DO NOT generate symbolic, philosophical, interpretive, or opinion-based questions.\n"
        "3) Avoid 'what does it mean/represent/symbolize' style.\n"
        "4) The hint is a HARD constraint; follow it.\n"
        "5) Difficulty must be strictly adhered to.\n"
    )

    difficulty_rules = {
        "easy": (
            "- Easy: direct identification or simple facts.\n"
            "- Use obvious cues.\n"
        ),
        "medium": (
            "- Medium: still factual, but avoid extremely easy prompts (e.g., main character names).\n"
            "- Prefer specific details and close distractors for MCQ.\n"
        ),
        "hard": (
            "- Hard: factual but less obvious; require specific detail recognition.\n"
            "- Avoid extremely obvious examples; prefer less-common but verifiable entities.\n"
            "- Distractors must be very close and plausible.\n"
        ),
        "expert": (
            "- Expert: factual and precise; still single-answer.\n"
            "- DO NOT use globally obvious/household examples (e.g., Coca-Cola, Apple, Google, Nike, McDonald's).\n"
            "- Choose less-obvious but still verifiable entities within the category and region scope.\n"
            "- For MCQ: distractors must be extremely close (same industry/type/region).\n"
        ),
    }

    scope_line = f"Category scope/region: {cat.scope or cat.region or 'saudi'}\n"
    hint_line = f"Hint/Prompt: {hint.strip() if hint else '(none)'}\n"
    subtopic_line = f"Subtopic constraint: {subtopic.strip() if subtopic else '(none)'}\n"

    system_msg = (
        "You are a production question generator for a Saudi family-safe trivia game. "
        "You output ONLY valid JSON, no markdown. "
        "You must follow instructions exactly. "
        "Arabic must be Modern Standard Arabic."
    )

    def _parse_json(raw: str):
        raw = (raw or "").strip()
        if raw.startswith("```"):
            raw = raw.strip("`")
            if "\n" in raw:
                raw = raw.split("\n", 1)[1]
        return json.loads(raw)

    def _llm(messages, temperature=0.2):
        resp = client.chat.completions.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-4.1-mini"),
            messages=messages,
            temperature=temperature,
        )
        return (resp.choices[0].message.content or "").strip()

    def _search_wikimedia(query: str, limit: int = 10):
        try:
            from utils.wikipedia_tools import search_commons_images
            return search_commons_images(query=query, limit=limit) or []
        except Exception:
            return []

    created = 0
    errors = []
    items = []

    # ----------------------------
    # TEXT MODE
    # ----------------------------
    if question_mode == "TEXT":
        if is_mcq:
            prompt = (
                f"{common_rules}{difficulty_rules[difficulty]}"
                + scope_line
                + hint_line
                + subtopic_line
                + "Generate a STRICT JSON array of length "
                + str(count)
                + " where each item has:\n"
                + "{stem_en, stem_ar, option1_en, option2_en, option3_en, option4_en, "
                + "option1_ar, option2_ar, option3_ar, option4_ar, correct_option_index, "
                + "answer_en, answer_ar, hint}\n"
                + "Constraints for MCQ:\n"
                + "- Exactly 4 options.\n"
                + "- Exactly 1 correct option.\n"
                + "- Distractors must be close and of the same type/category.\n"
                + "- Do NOT put the correct answer inside the question stem.\n"
                + "- answer_en/answer_ar must equal the correct option text.\n"
            )
        else:
            prompt = (
                f"{common_rules}{difficulty_rules[difficulty]}"
                + scope_line
                + hint_line
                + subtopic_line
                + "Generate a STRICT JSON array of length "
                + str(count)
                + " where each item has:\n"
                + "{stem_en, stem_ar, answer_en, answer_ar, hint}\n"
                + "Constraints:\n"
                + "- The answer must be a single concrete phrase (not interpretive).\n"
                + "- Do NOT include the answer inside the question stem.\n"
            )

        raw = ""
        try:
            raw = _llm(
                [
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.35,
            )
            items = _parse_json(raw)
        except Exception as e:
            errors.append(f"LLM/JSON parse error: {e}")
            items = []

        # Save
        for item in items:
            try:
                stem_en_val = (item.get("stem_en") or "").strip()
                stem_ar_val = (item.get("stem_ar") or "").strip()
                ans_en_val = (item.get("answer_en") or "").strip()
                ans_ar_val = (item.get("answer_ar") or "").strip()
                hint_val = (item.get("hint") or hint or "").strip()

                if not stem_ar_val:
                    continue

                norm_key = _normalize_question_text(stem_en_val, stem_ar_val, ans_en_val, ans_ar_val)
                sig = _sha(norm_key) if norm_key else None
                if sig:
                    existing = db.query(Question).filter(Question.signature == sig).first()
                    if existing:
                        continue

                q = Question(
                    category_id=cat.id,
                    stem_en=stem_en_val or None,
                    stem_ar=stem_ar_val,
                    answer_en=ans_en_val or None,
                    answer_ar=ans_ar_val or None,
                    hint=hint_val or None,
                    subtopic=(subtopic.strip() or None),
                    difficulty=difficulty,
                    question_mode="TEXT",
                    question_type="text",
                    media_type=None,
                    answer_type=("mcq_selection" if is_mcq else "text_input"),
                    region=cat.scope or "saudi",
                    status="needs_factcheck",
                    signature=sig if sig else None,
                )

                if is_mcq:
                    # validate options
                    opts_en = [(item.get(f"option{i}_en") or "").strip() for i in range(1,5)]
                    opts_ar = [(item.get(f"option{i}_ar") or "").strip() for i in range(1,5)]
                    if not all(opts_ar) or not all(opts_en):
                        continue
                    try:
                        ci = int(item.get("correct_option_index") or 0)
                    except Exception:
                        ci = 0
                    if ci not in (1,2,3,4):
                        continue
                    # assign
                    q.option1_en, q.option2_en, q.option3_en, q.option4_en = opts_en
                    q.option1_ar, q.option2_ar, q.option3_ar, q.option4_ar = opts_ar
                    q.correct_option_index = ci

                db.add(q)
                created += 1
            except Exception as e:
                errors.append(str(e))
                continue

        db.commit()
        return templates.TemplateResponse(
            "ai_generate.html",
            {"request": request, "categories": db.query(Category).all(), "message": f"Generated {created} questions.", "errors": errors},
        )

    # ----------------------------
    # MEDIA MODE (media-first)
    # ----------------------------

    # Media intent prompt: must yield concrete identification targets
    intent_prompt = (
        f"{common_rules}{difficulty_rules[difficulty]}"
        + scope_line
        + hint_line
        + subtopic_line
        + f"MEDIA MODE. media_type={media_type}.\n"
        + "Return STRICT JSON array of length "
        + str(count)
        + " where each item has:\n"
        + "{media_search_query, expected_answer_en, expected_answer_ar, question_style, hint}\n"
        + "question_style must be one of: logo_identification, picture_identification, audio_identification, video_identification, youtube_identification.\n"
        + "expected_answer must be a concrete name (company/brand, movie title, singer, instrument, place, object).\n"
        + "media_search_query MUST be specific (include key nouns), not generic.\n"
    )

    try:
        raw = _llm(
            [
                {"role": "system", "content": system_msg},
                {"role": "user", "content": intent_prompt},
            ],
            temperature=0.25,
        )
        intents = _parse_json(raw)
    except Exception as e:
        errors.append(f"Media intent error: {e}")
        intents = []

    from agents.media_agent import collect_media_candidates

    for intent in intents:
        try:
            q_hint = (intent.get("hint") or hint or "").strip()
            query = (intent.get("media_search_query") or "").strip()
            exp_en = (intent.get("expected_answer_en") or "").strip()
            exp_ar = (intent.get("expected_answer_ar") or "").strip()
            if not exp_ar:
                exp_ar = exp_en  # fallback; better than empty
            if not query or not exp_en:
                continue

            # Get media candidates: prefer Wikimedia for logo/picture
            urls = []
            if media_type in ("logo", "picture"):
                urls = _search_wikimedia(query, limit=12)
            # fallback to generic search
            if not urls and media_type == "picture":
                try:
                    cands = collect_media_candidates(query)
                    urls = []
                    for c in cands:
                        if isinstance(c, dict):
                            u = c.get("url")
                        else:
                            u = None
                        if u:
                            urls.append(u)
                    urls = urls[:12]
                except Exception:
                    urls = []

            if not urls:
                # Create question anyway but mark review_required
                selected_url = None
                media_status = "REVIEW_REQUIRED"
                media_conf = 0.0
                media_src = None
            else:
                selected_url = urls[0]
                media_status = "PENDING"
                media_conf = 0.8
                media_src = "wikimedia" if media_type in ("logo","picture") else "search"

            # Question generation prompt (must refer to media)
            if is_mcq:
                q_prompt = (
                    f"{common_rules}{difficulty_rules[difficulty]}"
                    + f"Create ONE media-based identification question. media_type={media_type}.\nFor difficulty=hard/expert: do NOT use extremely obvious household examples; choose less-obvious but verifiable entities.\n"
                    + f"Media URL: {selected_url or '(none)'}\n"
                    + f"Correct answer (English): {exp_en}\n"
                    + f"Correct answer (Arabic): {exp_ar}\n"
                    + f"Hint: {q_hint or '(none)'}\n"
                    + "Return STRICT JSON object with keys:\n"
                    + "{stem_en, stem_ar, option1_en, option2_en, option3_en, option4_en, option1_ar, option2_ar, option3_ar, option4_ar, correct_option_index, answer_en, answer_ar, hint}\n"
                    + "Constraints:\n"
                    + "- Stem must explicitly reference the media (logo/image/audio/video).\n"
                    + "- Options must be close distractors of the same type.\n"
                    + "- Exactly 1 correct.\n"
                    + "- answer_en/answer_ar must equal the correct option.\n"
                )
            else:
                q_prompt = (
                    f"{common_rules}{difficulty_rules[difficulty]}"
                    + f"Create ONE media-based identification question. media_type={media_type}.\nFor difficulty=hard/expert: do NOT use extremely obvious household examples; choose less-obvious but verifiable entities.\n"
                    + f"Media URL: {selected_url or '(none)'}\n"
                    + f"Correct answer (English): {exp_en}\n"
                    + f"Correct answer (Arabic): {exp_ar}\n"
                    + f"Hint: {q_hint or '(none)'}\n"
                    + "Return STRICT JSON object with keys:\n"
                    + "{stem_en, stem_ar, answer_en, answer_ar, hint}\n"
                    + "Constraints:\n"
                    + "- Stem must explicitly reference the media.\n"
                    + "- Answer must be concrete identification.\n"
                )

            q_raw = _llm(
                [
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": q_prompt},
                ],
                temperature=0.25,
            )
            q_item = _parse_json(q_raw)

            stem_en_val = (q_item.get("stem_en") or "").strip()
            stem_ar_val = (q_item.get("stem_ar") or "").strip()
            ans_en_val = (q_item.get("answer_en") or exp_en).strip()
            ans_ar_val = (q_item.get("answer_ar") or exp_ar).strip()
            hint_val = (q_item.get("hint") or q_hint or "").strip()

            if not stem_ar_val:
                continue

            norm_key = _normalize_question_text(stem_en_val, stem_ar_val, ans_en_val, ans_ar_val)
            sig = _sha(norm_key) if norm_key else None
            if sig:
                if db.query(Question).filter(Question.signature == sig).first():
                    continue

            q = Question(
                category_id=cat.id,
                stem_en=stem_en_val or None,
                stem_ar=stem_ar_val,
                answer_en=ans_en_val or None,
                answer_ar=ans_ar_val or None,
                hint=hint_val or None,
                subtopic=(subtopic.strip() or None),
                difficulty=difficulty,
                question_mode="MEDIA",
                media_type=media_type,
                question_type=media_type,  # keep legacy field aligned
                answer_type=("mcq_selection" if is_mcq else "text_input"),
                region=cat.scope or "saudi",
                status="needs_factcheck",
                signature=sig if sig else None,
                media_status=media_status,
                media_confidence=media_conf,
                media_source=media_src,
                media_intent_json=json.dumps(intent, ensure_ascii=False),
            )

            # set selected media fields
            if selected_url:
                # legacy url field + new fields
                q.url = selected_url
                if hasattr(q, "media_url"):
                    q.media_url = selected_url
                if hasattr(q, "media_query"):
                    q.media_query = query
                if hasattr(q, "media_selected_source"):
                    q.media_selected_source = media_src
                if hasattr(q, "media_selected_score"):
                    q.media_selected_score = str(media_conf)
                if hasattr(q, "media_type"):
                    q.media_type = media_type

            if is_mcq:
                opts_en = [(q_item.get(f"option{i}_en") or "").strip() for i in range(1,5)]
                opts_ar = [(q_item.get(f"option{i}_ar") or "").strip() for i in range(1,5)]
                if not all(opts_ar) or not all(opts_en):
                    continue

                # Determine correct index by matching answer text (more reliable than trusting the model index)
                model_ci = 0
                try:
                    model_ci = int(q_item.get("correct_option_index") or 0)
                except Exception:
                    model_ci = 0

                # Prefer matching by English answer, else expected answer, else model index
                ans_key = (ans_en_val or "").strip().lower()
                exp_key = (exp_en or "").strip().lower()
                correct_idx = 0
                for i_opt, opt in enumerate(opts_en, start=1):
                    if ans_key and opt.lower() == ans_key:
                        correct_idx = i_opt
                        break
                if correct_idx == 0 and exp_key:
                    for i_opt, opt in enumerate(opts_en, start=1):
                        if opt.lower() == exp_key:
                            correct_idx = i_opt
                            break
                if correct_idx == 0 and model_ci in (1,2,3,4):
                    correct_idx = model_ci
                if correct_idx == 0:
                    continue

                q.option1_en, q.option2_en, q.option3_en, q.option4_en = opts_en
                q.option1_ar, q.option2_ar, q.option3_ar, q.option4_ar = opts_ar
                q.correct_option_index = correct_idx

                # Ensure stored answer matches correct option
                q.answer_en = opts_en[correct_idx-1]
                q.answer_ar = opts_ar[correct_idx-1]

            db.add(q)
            db.flush()  # allocate q.id for media candidates

            # For MEDIA mode, pre-populate media_candidates so UI is not blank.
            if question_mode == "MEDIA":
                # clear any existing candidates for this question (safety)
                db.query(MediaCandidate).filter(MediaCandidate.question_id == q.id).delete()
                if urls:
                    # score descending by order; mark the first as selected
                    for k, u in enumerate(urls[:12]):
                        db.add(
                            MediaCandidate(
                                question_id=q.id,
                                source=media_src or "search",
                                url=u,
                                title=None,
                                score=float(max(0.0, media_conf - (k * 0.03))),
                                meta_json=None,
                                selected=(k == 0),
                            )
                        )

            created += 1

        except Exception as e:
            errors.append(str(e))
            continue

    db.commit()
    return templates.TemplateResponse(
        "ai_generate.html",
        {"request": request, "categories": db.query(Category).all(), "message": f"Generated {created} questions.", "errors": errors},
    )
@app.post("/agents/media")
def agents_media(
    request: Request,
    db: Session = Depends(get_db),
    question_ids: str = Form(""),
):
    _require_login(request)

    ids: List[int] = []
    if question_ids.strip():
        try:
            ids = [int(x) for x in question_ids.split(",") if x.strip()]
        except Exception:
            ids = []

    if not ids:
        qs = (
            db.query(Question)
            .filter(Question.media_status == "pending")
            .order_by(Question.id.desc())
            .limit(20)
            .all()
        )
        ids = [q.id for q in qs]

    if not ids:
        return RedirectResponse("/agents", status_code=303)

    run_media_agent_for_question_ids(db, ids)

    _log_audit(
        db,
        _current_user(request),
        "run_media_agent",
        "Question",
        None,
        {"question_ids": ids},
    )

    return RedirectResponse("/agents", status_code=303)


# -------------------------------------------------------------------
# Fact-check & validate agents
# -------------------------------------------------------------------

@app.post("/agents/factcheck")
def agents_factcheck(
    request: Request,
    db: Session = Depends(get_db),
    question_ids: str = Form(""),
):
    _require_login(request)

    ids: List[int] = []
    if question_ids.strip():
        try:
            ids = [int(x) for x in question_ids.split(",") if x.strip()]
        except Exception:
            ids = []

    if not ids:
        qs = (
            db.query(Question)
            .filter(Question.status == "needs_factcheck")
            .order_by(Question.id.desc())
            .limit(20)
            .all()
        )
        ids = [q.id for q in qs]

    if not ids:
        return RedirectResponse("/agents", status_code=303)

    run_factcheck_agent_for_question_ids(db, ids)

    _log_audit(
        db,
        _current_user(request),
        "run_factcheck_agent",
        "Question",
        None,
        {"question_ids": ids},
    )

    return RedirectResponse("/agents", status_code=303)


@app.post("/agents/validate")
def agents_validate(
    request: Request,
    db: Session = Depends(get_db),
    question_ids: str = Form(""),
):
    _require_login(request)

    ids: List[int] = []
    if question_ids.strip():
        try:
            ids = [int(x) for x in question_ids.split(",") if x.strip()]
        except Exception:
            ids = []

    if not ids:
        qs = (
            db.query(Question)
            .filter(Question.status == "needs_validation")
            .order_by(Question.id.desc())
            .limit(20)
            .all()
        )
        ids = [q.id for q in qs]

    if not ids:
        return RedirectResponse("/agents", status_code=303)

    run_validate_agent_for_question_ids(db, ids)

    _log_audit(
        db,
        _current_user(request),
        "run_validate_agent",
        "Question",
        None,
        {"question_ids": ids},
    )

    return RedirectResponse("/agents", status_code=303)


# -------------------------------------------------------------------
# Agents overview
# -------------------------------------------------------------------

@app.get("/agents", response_class=HTMLResponse)
def agents_overview(request: Request, db: Session = Depends(get_db)):
    _require_login(request)

    pending_media = (
        db.query(Question).filter(Question.media_status == "pending").count()
    )
    pending_factcheck = (
        db.query(Question).filter(Question.status == "needs_factcheck").count()
    )
    pending_validation = (
        db.query(Question).filter(Question.status == "needs_validation").count()
    )

    return templates.TemplateResponse(
        "agents.html",
        {
            "request": request,
            "pending_media": pending_media,
            "pending_factcheck": pending_factcheck,
            "pending_validation": pending_validation,
            "user": _current_user(request),
        },
    )


# -------------------------------------------------------------------
# Export
# -------------------------------------------------------------------

@app.get("/export", response_class=HTMLResponse)
def export_view(request: Request, db: Session = Depends(get_db)):
    _require_login(request)
    questions = db.query(Question).order_by(Question.id.asc()).all()
    cats = db.query(Category).all()
    cats_map = {c.id: c for c in cats}
    return templates.TemplateResponse(
        "export.html",
        {
            "request": request,
            "questions": questions,
            "categories": cats,
            "cats_map": cats_map,
            "user": _current_user(request),
        },
    )