
def pick_short_clip(url: str) -> str:
    """For now we rely on YouTube / video hosts directly.

    Real implementation could trim clips; here we just keep the URL.
    """
    return url
